import { createClient } from 'npm:@supabase/supabase-js@2';

const allowedOrigin = 'https://pacharapoltu92280.github.io';
const corsHeaders = {
  'Access-Control-Allow-Origin': allowedOrigin,
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
  'Vary': 'Origin',
};
const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: corsHeaders });

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  if (req.method !== 'POST') return reply({ error: 'Method not allowed' }, 405);
  const requestOrigin = req.headers.get('origin');
  if (requestOrigin && requestOrigin !== allowedOrigin) return reply({ error: 'Origin not allowed' }, 403);

  const bearer = req.headers.get('authorization') || '';
  if (!bearer.startsWith('Bearer ')) return reply({ error: 'Login required' }, 401);

  const url = Deno.env.get('SUPABASE_URL');
  const publicKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !publicKey || !serviceKey) {
    console.error('DELETE_TASK_CONFIG_MISSING');
    return reply({ error: 'Server configuration missing' }, 500);
  }

  const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const client = createClient(url, publicKey, { auth: { persistSession: false, autoRefreshToken: false } });

  try {
    const { data: { user }, error: authErr } = await admin.auth.getUser(bearer.slice(7));
    if (authErr || !user?.email) return reply({ error: 'Invalid session' }, 401);

    const { data: profile, error: profileErr } = await admin.from('profiles')
      .select('role').eq('id', user.id).single();
    if (profileErr) {
      console.error('DELETE_TASK_PROFILE_LOOKUP_FAILED', profileErr.code, profileErr.message);
      return reply({ error: 'Profile lookup failed' }, 500);
    }
    if (!['admin', 'member'].includes(profile?.role || '')) return reply({ error: 'Not authorized' }, 403);

    const body = await req.json().catch(() => null);
    if (!body || (profile?.role === 'admin' && (typeof body.password !== 'string' || !body.password)) ||
        typeof body.taskId !== 'string' ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.taskId)) {
      return reply({ error: 'Invalid input' }, 400);
    }

    // Admin must confirm their password. Member may only delete tasks assigned as Main PIC.
    if (profile?.role === 'admin') {
      const { data: login, error: loginErr } = await client.auth.signInWithPassword({
        email: user.email, password: body.password,
      });
      if (loginErr || login.user?.id !== user.id) return reply({ error: 'Invalid admin password' }, 403);
    } else {
      const { data: owned, error: ownedErr } = await admin.from('tasks')
        .select('id').eq('id', body.taskId).eq('assigned_to', user.id)
        .is('deleted_at', null).maybeSingle();
      if (ownedErr) return reply({ error: 'Task permission check failed' }, 500);
      if (!owned) return reply({ error: 'Only the Main PIC may delete this task' }, 403);
    }

    let updateQuery = admin.from('tasks')
      .update({ deleted_at: new Date().toISOString(), deleted_by: user.id })
      .eq('id', body.taskId).is('deleted_at', null);
    if (profile?.role === 'member') updateQuery = updateQuery.eq('assigned_to', user.id);
    const { data: updated, error: updateErr } = await updateQuery
      .select('id, deleted_at').maybeSingle();

    if (updateErr) {
      console.error('DELETE_TASK_UPDATE_FAILED', updateErr.code, updateErr.message);
      return reply({ error: 'Database update failed' }, 500);
    }
    if (!updated?.deleted_at) {
      return reply({ error: 'Task not found, already deleted, or not updated' }, 404);
    }
    return reply({ success: true, deleted_at: updated.deleted_at });
  } catch (err) {
    console.error('DELETE_TASK_UNEXPECTED_ERROR', err);
    return reply({ error: 'Unexpected server error' }, 500);
  }
});
