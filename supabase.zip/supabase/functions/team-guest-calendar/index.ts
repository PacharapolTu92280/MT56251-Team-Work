import { createClient } from 'npm:@supabase/supabase-js@2';

const origin = 'https://pacharapoltu92280.github.io';
const cors = {
  'Access-Control-Allow-Origin': origin,
  'Access-Control-Allow-Headers': 'apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Vary': 'Origin',
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store'
};
const reply = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: cors });

Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (req.method !== 'GET') return reply({ error: 'Method not allowed' }, 405);
  if (req.headers.get('origin') !== origin) return reply({ error: 'Origin not allowed' }, 403);
  const url = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !key) return reply({ error: 'Server not configured' }, 503);
  try {
    const client = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
    // Global visibility is checked on the server for EVERY request.
    const { data: setting, error: settingError } = await client.from('team_guest_calendar_settings')
      .select('is_visible').eq('id', 1).single();
    if (settingError || !setting) {
      console.error('GUEST_CALENDAR_SETTINGS', settingError?.message);
      return reply({ error: 'Calendar unavailable' }, 500);
    }
    if (!setting.is_visible) return reply({ tasks: [] });
    // Explicit allowlist: NEVER return description, owner, comments, history, attachments, or internal IDs.
    const { data, error } = await client.from('tasks')
      .select('title,start_date,due_date,status')
      .is('deleted_at', null)
      .neq('status', 'Completed')
      .order('start_date', { ascending: true })
      .limit(500);
    if (error) { console.error('GUEST_CALENDAR_READ', error.code, error.message); return reply({ error: 'Calendar unavailable' }, 500); }
    return reply({ tasks: (data || []).map(t => ({ title: t.title, start_date: t.start_date, due_date: t.due_date, status: t.status })) });
  } catch (e) {
    console.error('GUEST_CALENDAR_ERROR', e);
    return reply({ error: 'Server error' }, 500);
  }
});
