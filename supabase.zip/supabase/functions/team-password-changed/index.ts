import { createClient } from 'npm:@supabase/supabase-js@2';
const headers = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Content-Type': 'application/json' };
Deno.serve(async req => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers });
  const send = (body: unknown, status=200) => new Response(JSON.stringify(body), { status, headers });
  if (req.method !== 'POST') return send({ error: 'Method not allowed' },405);
  const bearer = req.headers.get('Authorization')||'';
  if (!bearer.startsWith('Bearer ')) return send({ error: 'Unauthorized' },401);
  const url = Deno.env.get('SUPABASE_URL')!, anon = Deno.env.get('SUPABASE_ANON_KEY')!, secret = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const userClient = createClient(url,anon,{auth:{persistSession:false}});
  const serviceClient = createClient(url,secret,{auth:{persistSession:false}});
  const { data, error } = await userClient.auth.getUser(bearer.slice(7));
  if(error||!data.user) return send({ error: 'Invalid session' },401);
  // Only the authenticated owner can clear their own flag.
  const {error: updateError} = await serviceClient.from('profiles').update({must_change_password:false}).eq('id',data.user.id);
  if(updateError) return send({error:'Update failed'},500);
  return send({success:true});
});
