import { createClient } from 'npm:@supabase/supabase-js@2';
const origin='https://pacharapoltu92280.github.io';
const headers={'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json','Vary':'Origin'};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
const sha256=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(b=>b.toString(16).padStart(2,'0')).join('');
Deno.serve(async req=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply({error:'Method not allowed'},405);
 if(req.headers.get('origin')!==origin)return reply({error:'Origin not allowed'},403);
 try{
  const url=Deno.env.get('SUPABASE_URL'),service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  const captchaSecret=Deno.env.get('TURNSTILE_SECRET_KEY'),pepper=Deno.env.get('GUEST_RATE_LIMIT_PEPPER');
  if(!url||!service||!captchaSecret||!pepper)return reply({error:'Server not configured'},503);
  if(Number(req.headers.get('content-length')||0)>12000)return reply({error:'Payload too large'},413);
  const body=await req.json();
  if(!body||typeof body.captchaToken!=='string'||body.captchaToken.length>3000)return reply({error:'CAPTCHA required'},400);
  const ip=req.headers.get('cf-connecting-ip')||req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()||'';
  if(!ip)return reply({error:'Client address unavailable'},400);
  const verify=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({secret:captchaSecret,response:body.captchaToken,remoteip:ip})});
  const proof=await verify.json();
  if(!proof.success||proof.hostname!=='pacharapoltu92280.github.io')return reply({error:'CAPTCHA verification failed'},403);
  const valid=(s:unknown,n:number)=>typeof s==='string'&&s.trim().length>0&&s.trim().length<=n;
  if(!valid(body.requesterName,100)||!valid(body.contactEmail,254)||!valid(body.title,200)||typeof body.details!=='string'||body.details.length>3000||!['Daily Operations','Project Response','Process Improvement'].includes(body.category)||!['P1','P2','P3','P4'].includes(body.priority)||!/^\S+@\S+\.\S+$/.test(body.contactEmail)||!(body.dueDate===null||/^\d{4}-\d{2}-\d{2}$/.test(body.dueDate)))return reply({error:'Invalid request fields'},400);
  const admin=createClient(url,service,{auth:{persistSession:false,autoRefreshToken:false}});
  const ipHash=await sha256(pepper+':'+ip);
  const {data,error}=await admin.rpc('team391_submit_guest_request',{p_ip_hash:ipHash,p_requester_name:body.requesterName,p_contact_email:body.contactEmail,p_title:body.title,p_details:body.details,p_category:body.category,p_priority:body.priority,p_due_date:body.dueDate});
  if(error){console.error('guest request',error.code,error.message);return reply({error:error.message.includes('Rate limit')?'Too many requests. Try again later.':'Unable to submit request'},error.message.includes('Rate limit')?429:400)}
  // Issue a one-time tracking credential for new requests; never expose it through list endpoints.
  const secretBytes=crypto.getRandomValues(new Uint8Array(32));
  const trackingCode=Array.from(secretBytes).map(b=>b.toString(16).padStart(2,'0')).join('');
  const tokenHash=await sha256(trackingCode);
  const {error:tokenError}=await admin.from('task_requests').update({tracking_token_hash:tokenHash}).eq('id',data);
  if(tokenError){console.error('TRACKING_TOKEN_ERROR',tokenError.code);return reply({success:true,requestId:data,trackingUnavailable:true},201);}
  return reply({success:true,requestId:data,trackingCode},201);
 }catch(e){console.error('guest request failed',e);return reply({error:'Server error'},500)}
});
