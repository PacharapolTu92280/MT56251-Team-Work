import { createClient } from 'npm:@supabase/supabase-js@2';
const origin='https://pacharapoltu92280.github.io';
const headers={'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'content-type, apikey','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json','Cache-Control':'no-store','Vary':'Origin'};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
const sha256=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(b=>b.toString(16).padStart(2,'0')).join('');
Deno.serve(async req=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply({error:'Method not allowed'},405);
 if(req.headers.get('origin')!==origin)return reply({error:'Origin not allowed'},403);
 try{
  if(Number(req.headers.get('content-length')||0)>2000)return reply({error:'Invalid request'},400);
  const body=await req.json();
  if(!/^[a-f0-9-]{36}$/i.test(body?.requestId||'')||!/^[a-f0-9]{64}$/i.test(body?.trackingCode||''))return reply({error:'Invalid request'},400);
  const url=Deno.env.get('SUPABASE_URL'),key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');if(!url||!key)return reply({error:'Service unavailable'},503);
  const db=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:r,error}=await db.from('task_requests').select('id,status,linked_task_id,tracking_token_hash').eq('id',body.requestId).maybeSingle();
  const hash=await sha256(body.trackingCode.toLowerCase());
  if(error||!r||!r.tracking_token_hash||r.tracking_token_hash!==hash)return reply({error:'ไม่พบคำขอหรือ Tracking Code ไม่ถูกต้อง'},404);
  let taskStatus=null,progress=null;
  if(r.status==='approved'&&r.linked_task_id){const {data:t}=await db.from('tasks').select('status,progress,deleted_at').eq('id',r.linked_task_id).maybeSingle();if(t&&!t.deleted_at){taskStatus=t.status;progress=Math.max(0,Math.min(100,Number(t.progress)||0));}}
  return reply({requestStatus:r.status,taskStatus,progress});
 }catch(e){console.error('TRACK_ERROR',e);return reply({error:'Service error'},500);}
});
