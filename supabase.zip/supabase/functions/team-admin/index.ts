import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
};
const respond = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: cors });
const uuid = (s: unknown) => typeof s === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
const validPassword = (s: unknown) => typeof s === 'string' && s.length >= 12 && s.length <= 128;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (req.method !== 'POST') return respond({ error: 'Method not allowed' }, 405);
  const authHeader = req.headers.get('Authorization') || '';
  if (!authHeader.startsWith('Bearer ')) return respond({ error: 'Login required' }, 401);
  const url = Deno.env.get('SUPABASE_URL');
  const publicKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !publicKey || !serviceKey) return respond({ error: 'Server configuration missing' }, 500);
  const callerClient = createClient(url, publicKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const adminClient = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });
  try {
    const { data: caller, error: authError } = await callerClient.auth.getUser(authHeader.slice(7));
    if (authError || !caller.user) return respond({ error: 'Invalid session' }, 401);
    const { data: profile, error: profileError } = await adminClient.from('profiles').select('role').eq('id', caller.user.id).single();
    if (profileError || profile?.role !== 'admin') return respond({ error: 'Admin only' }, 403);
    const input = await req.json();
    const action = input?.action;
    if (action === 'list') {
      const { data, error } = await adminClient.auth.admin.listUsers({ page: 1, perPage: 200 });
      if (error) throw error;
      return respond({ users: data.users.map(u => ({ id: u.id, email: u.email, banned_until: u.banned_until })) });
    }
    if (action === 'create') {
      const email = String(input.email || '').trim().toLowerCase();
      const name = String(input.name || '').trim();
      const role = input.role === 'admin' ? 'admin' : 'member';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || name.length < 1 || name.length > 100 || !validPassword(input.password)) return respond({ error: 'Valid email, name, and password (12-128 characters) required' }, 400);
      const { data, error } = await adminClient.auth.admin.createUser({ email, password: input.password, email_confirm: true, user_metadata: { display_name: name } });
      if (error) throw error;
      // Profile trigger defaults to member. Promote through privileged RPC only.
      const { error: pError } = await adminClient.from('profiles').update({ display_name: name, must_change_password: true }).eq('id', data.user.id);
      if (pError) return respond({ error: 'User created but profile update failed; inspect before retrying' }, 500);
      if (role === 'admin') {
        const { error: rError } = await adminClient.rpc('team_set_role', { target_id: data.user.id, new_role: 'admin' });
        if (rError) return respond({ error: 'User created as member, promotion failed; inspect before retrying' }, 500);
      }
      return respond({ user: { id: data.user.id, email }, must_change_password: true });
    }
    if (!uuid(input.userId)) return respond({ error: 'Valid userId required' }, 400);
    const targetId = input.userId;
    const { data: targetProfile } = await adminClient.from('profiles').select('role').eq('id', targetId).maybeSingle();
    if (!targetProfile) return respond({ error: 'User not found' }, 404);
    if (action === 'reset_password') {
      if (!validPassword(input.password)) return respond({ error: 'Password must be 12-128 characters' }, 400);
      const { error } = await adminClient.auth.admin.updateUserById(targetId, { password: input.password });
      if (error) throw error;
      const { error: flagError } = await adminClient.from('profiles').update({ must_change_password: true }).eq('id', targetId);
      if (flagError) throw flagError;
      return respond({ success: true });
    }
    if (action === 'set_role') {
      if (!['admin', 'member'].includes(input.role)) return respond({ error: 'Invalid role' }, 400);
      const { error } = await adminClient.rpc('team_set_role', { target_id: targetId, new_role: input.role });
      if (error) return respond({ error: error.message }, 400);
      return respond({ success: true });
    }
    if (action === 'ban' || action === 'unban') {
      if (targetId === caller.user.id && action === 'ban') return respond({ error: 'Cannot ban yourself' }, 400);
      if (action === 'ban' && targetProfile.role === 'admin') {
        const { count } = await adminClient.from('profiles').select('*', { head: true, count: 'exact' }).eq('role', 'admin');
        if ((count || 0) <= 1) return respond({ error: 'Cannot ban the last admin' }, 400);
      }
      const { error } = await adminClient.auth.admin.updateUserById(targetId, { ban_duration: action === 'ban' ? '876000h' : 'none' });
      if (error) throw error;
      return respond({ success: true });
    }
    return respond({ error: 'Unknown action' }, 400);
  } catch (error) {
    console.error('team-admin error', error);
    return respond({ error: error instanceof Error ? error.message : 'Unexpected error' }, 500);
  }
});
